const config = {
  Authentication: "0xa5F0D0aE58caF334bc0D6C0063eACEE0E7BDEF08",
  RideShare: "0xDb59BCE3980CeDbaD876e001583236bdf4D5a58B",
};
export default config;
