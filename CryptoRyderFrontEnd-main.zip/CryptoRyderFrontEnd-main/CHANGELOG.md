# CHANGELOG.md

## [1.0.1] - 2020-10-19

Fix issue with testimonail image on mobile

## [1.0.0] - 2020-10-15

First release
